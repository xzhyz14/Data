package com.example.myapplication5;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class BlankFragment extends Fragment {
    private View root;
    private String textViewString;

    public BlankFragment() {
    }

    public static BlankFragment newInstance(String textView) {
        BlankFragment fragment = new BlankFragment();
        Bundle args = new Bundle();
        args.putString("null", textView);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            textViewString = getArguments().getString("null");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (root == null) {
            root = inflater.inflate(R.layout.fragment_blank, container, false);
        }
        changeTextView();
        return root;
    }

    private void changeTextView() {
        TextView textView = root.findViewById(R.id.fb_textView);
        textView.setText(textViewString);
    }
}