package com.example.myapplication5;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private ViewPager2 viewPager;
    private LinearLayout Lwx, Ltxl, Lfx, Lw;
    private ImageView Iwx, Itxl, Ifx, Iw, Ic;
    private List<Fragment> fragmentList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViewPager();
        initBottom();
    }

    /**
     * 初始化选择栏
     */
    private void initBottom() {
        Lwx = findViewById(R.id.bottom_weixin);
        Ltxl = findViewById(R.id.bottom_tongxunlu);
        Lfx = findViewById(R.id.bottom_faxian);
        Lw = findViewById(R.id.bottom_wo);

        Lwx.setOnClickListener(this);
        Ltxl.setOnClickListener(this);
        Lfx.setOnClickListener(this);
        Lw.setOnClickListener(this);

        Iwx = findViewById(R.id.bottom_weixin_iv);
        Itxl = findViewById(R.id.bottom_tongxunlu_iv);
        Ifx = findViewById(R.id.bottom_faxian_iv);
        Iw = findViewById(R.id.bottom_wo_iv);

        Iwx.setSelected(true);
        Ic = Iwx;

    }

    /**
     * 初始化ViewPager
     */
    private void initViewPager() {
        fragmentList.add(BlankFragment.newInstance("微信"));
        fragmentList.add(BlankFragment.newInstance("通讯录"));
        fragmentList.add(BlankFragment.newInstance("发现"));
        fragmentList.add(BlankFragment.newInstance("我"));

        viewPager = findViewById(R.id.viewpager);
        MyAdapter myAdapter = new MyAdapter(getSupportFragmentManager(), getLifecycle(), fragmentList);
        viewPager.setAdapter(myAdapter);
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels);
            }

            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                changeIco(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                super.onPageScrollStateChanged(state);
            }
        });
    }

    /**
     * 点击事件
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        changeIco(v.getId());
        Log.e("TAG", v.getId() + "");
        Log.e("TAG", R.id.bottom_weixin + "");
    }

    /**
     * 导航栏的图标改变
     *
     * @param position
     */
    private void changeIco(int position) {
        if (position == R.id.bottom_weixin || position == 0) {
            Ic.setSelected(false);
            Ic = Iwx;
            Ic.setSelected(true);
            viewPager.setCurrentItem(0);
        } else if (position == R.id.bottom_tongxunlu || position == 1) {
            Ic.setSelected(false);
            Ic = Itxl;
            Ic.setSelected(true);
            viewPager.setCurrentItem(1);
        } else if (position == R.id.bottom_faxian || position == 2) {
            Ic.setSelected(false);
            Ic = Ifx;
            Ic.setSelected(true);
            viewPager.setCurrentItem(2);
        } else if (position == R.id.bottom_wo || position == 3) {
            Ic.setSelected(false);
            Ic = Iw;
            Ic.setSelected(true);
            viewPager.setCurrentItem(3);
        }
    }
}